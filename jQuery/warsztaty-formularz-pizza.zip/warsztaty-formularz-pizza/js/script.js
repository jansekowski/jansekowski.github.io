let zamowienie=$("#zamowienie");
let imie=$("#imie");
let nazwisko=$("#nazwisko");
let ulica=$("#ulica");
let dom=$("#dom");
let kod=$("#kod");
let miasto=$("#miasto");
let rodzaj=$("#rodzaj");
let sos1=$("#sos1");
let sos2=$("#sos2");
let rodo=$("#rodo");
let button=$("#button");
let errors=$("#errors");
let cena=$("#cena");


zamowienie.submit(function(e){
    if(imie.val()==""){
        e.preventDefault();
        $("#errors").text("WPISZ IMIĘ!");
    };
    if(nazwisko.val()==""){
        e.preventDefault();
        $("#errors").append("WPISZ NAZWISKO!");
    };
    if(ulica.val()==""){
        e.preventDefault();
        $("#errors").append("WPISZ ULICĘ!");
    };
    if(dom.val()==""){
        e.preventDefault();
        $("#errors").append("WPISZ NUMER DOMU!");
    };
    if(kod.val()==""){
        e.preventDefault();
        $("#errors").append("WPISZ KOD POCZTOWY!");
    };
    if(miasto.val()==""){
        e.preventDefault();
        $("#errors").append("WPISZ MIASTO!");
    };
    if(rodzaj.val()=="brak"){
        e.preventDefault();
        $("#errors").append("WYBIERZ PIZZĘ!");
    };
    if(!rodo.prop('checked')){
        e.preventDefault();
        $("#errors").append("WYRAŹ ZGODĘ NA RODO!");
    };
});

let tabelaCen=[
    {value: 1, price: 21},
    {value: 2, price: 22},
    {value: 3, price: 23},
    {value: 4, price: 24},
    {value: 5, price: 25},
];


rodzaj.change(function(){

    let rodzajPizzy= $(this).val();

    if(rodzajPizzy=="brak"){
        cena.text("0 PLN");
        return;
    }

    tabelaCen.forEach(function(elementTablicy){

        if(rodzajPizzy==elementTablicy.value){
            cena.text(elementTablicy.price + "PLN");
            return;
        }

    });

    console.log("Zmiana pizzy na "+rodzajPizzy);
});